using System;
using System.Collections.Generic;
using System.Windows.Threading;
using StarWarsLabyrinth.Models;
using StarWarsLabyrinth.Models.GoodCharacters;
using StarWarsLabyrinth.Models.EvilCharacters;

namespace StarWarsLabyrinth.Utils
{
    public class GameEngine
    {
        private int[,] maze;
        
        private Character playerCharacter;
        
        private List<Character> evilCharacters;
        
        private Location cupLocation;
        
        private bool isGameOver;
        private bool isGameWon;
        private bool playerHasMoved;

        private int rows;
        private int cols;
        
        public event EventHandler GameOver;
        public event EventHandler GameWon;
        public event EventHandler PlayerMoved;
        public event EventHandler EnemiesMoved;
        public event EventHandler PlayerCaught;
        
        private DispatcherTimer gameTimer;
        
        public GameEngine()
        {
            evilCharacters = new List<Character>();
            isGameOver = false;
            isGameWon = false;
            playerHasMoved = false; 

            gameTimer = new DispatcherTimer();
            gameTimer.Tick += OnGameTimerTick;
            gameTimer.Interval = TimeSpan.FromMilliseconds(1000); // Her saniyede bir düşmanlar hareket etsin
        }
        
        public void SetMaze(int[,] maze)
        {
            this.maze = maze;
            rows = maze.GetLength(0);
            cols = maze.GetLength(1);
        }
        
        public void SetPlayerCharacter(Character character)
        {
            playerCharacter = character;
        }
        
        public void SetEvilCharacters(List<Character> characters)
        {
            evilCharacters = characters;
        }
        
        public void SetCupLocation(Location location)
        {
            cupLocation = location;
        }
        

        public void StartGame()
        {
            isGameOver = false;
            isGameWon = false;
            playerHasMoved = false; 
            gameTimer.Start();
        }
        
        public void StopGame()
        {
            gameTimer.Stop();
        }
        
        private void OnGameTimerTick(object sender, EventArgs e)
        {
            if (isGameOver || isGameWon)
                return;

            if (playerHasMoved)
            {
                MoveEnemies();

                EnemiesMoved?.Invoke(this, EventArgs.Empty);

                CheckEnemyCatch();
            }
        }
        
        public void MovePlayer(int dx, int dy)
        {
            if (isGameOver || isGameWon)
                return;
                
            int newX = playerCharacter.GetLocation().GetX() + dx;
            int newY = playerCharacter.GetLocation().GetY() + dy;
            
            if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
            {
                if (newX == cupLocation.GetX() && newY == cupLocation.GetY())
                {
                    Console.WriteLine($"Oyuncu kupaya gidiyor! {playerCharacter.GetLocation().GetX()},{playerCharacter.GetLocation().GetY()} -> {newX},{newY}");
                    
                    playerCharacter.GetLocation().SetX(newX);
                    playerCharacter.GetLocation().SetY(newY);

                    if (!playerHasMoved)
                    {
                        playerHasMoved = true;
                        Console.WriteLine("Oyuncu ilk hareketini yaptı. Düşmanlar aktif!");
                    }

                    PlayerMoved?.Invoke(this, EventArgs.Empty);

                    Console.WriteLine("*** KUPAYA ULAŞILDI! OYUN KAZANILDI! ***");
                    isGameWon = true;
                    GameWon?.Invoke(this, EventArgs.Empty);
                    StopGame();
                    return;
                }
                else if (maze[newX, newY] == 0)
                {
                    Console.WriteLine($"Oyuncu {playerCharacter.GetLocation().GetX()},{playerCharacter.GetLocation().GetY()} -> {newX},{newY}");
                    
                    playerCharacter.GetLocation().SetX(newX);
                    playerCharacter.GetLocation().SetY(newY);

                    if (!playerHasMoved)
                    {
                        playerHasMoved = true;
                        Console.WriteLine("Oyuncu ilk hareketini yaptı. Düşmanlar aktif!");
                    }

                    PlayerMoved?.Invoke(this, EventArgs.Empty);

                    int playerX = playerCharacter.GetLocation().GetX();
                    int playerY = playerCharacter.GetLocation().GetY();
                    int cupX = cupLocation.GetX();
                    int cupY = cupLocation.GetY();
                    
                    Console.WriteLine($"KONUM KONTROLÜ: Oyuncu=({playerX},{playerY}), Kupa=({cupX},{cupY})");
                    
                    bool xMatches = (playerX == cupX);
                    bool yMatches = (playerY == cupY);
                    Console.WriteLine($"X eşleşiyor mu: {xMatches}, Y eşleşiyor mu: {yMatches}");
                    
                    if (xMatches && yMatches)
                    {
                        Console.WriteLine("*** KUPAYA ULAŞILDI! OYUN KAZANILDI! ***");
                        isGameWon = true;
                        GameWon?.Invoke(this, EventArgs.Empty);
                        StopGame();
                        return;
                    }
                    
                    if (Math.Abs(playerX - cupX) <= 0 && Math.Abs(playerY - cupY) <= 0)
                    {
                        Console.WriteLine("*** KUPAYA ÇOK YAKIN! ***");
                    }
                }
            }
        }
        
        private void MoveEnemies()
        {
            foreach (Character enemy in evilCharacters)
            {
                List<Location> path = enemy.ShortestPath(maze, playerCharacter.GetLocation());
                
                if (path.Count > 1) 
                {
                    Location nextLocation = path[1]; 
                    
                    if (enemy is KyloRen kyloRen)
                    {
                        Console.WriteLine("Kylo Ren hareket ediyor...");
                        if (path.Count > 2) 
                        {
                            nextLocation = path[2];
                            Console.WriteLine($"Kylo Ren 2 adım ilerliyor: {enemy.GetLocation().GetX()},{enemy.GetLocation().GetY()} -> {nextLocation.GetX()},{nextLocation.GetY()}");
                        }
                    }
                    else
                    {
                        string enemyType = enemy is DarthVader ? "DarthVader" : "Stormtrooper";
                        Console.WriteLine($"{enemyType} 1 adım ilerliyor: {enemy.GetLocation().GetX()},{enemy.GetLocation().GetY()} -> {nextLocation.GetX()},{nextLocation.GetY()}");
                    }
                    
                    enemy.GetLocation().SetX(nextLocation.GetX());
                    enemy.GetLocation().SetY(nextLocation.GetY());
                }
            }
        }
        
        private void CheckEnemyCatch()
        {
            foreach (Character enemy in evilCharacters)
            {
                if (enemy.GetLocation().GetX() == playerCharacter.GetLocation().GetX() && 
                    enemy.GetLocation().GetY() == playerCharacter.GetLocation().GetY())
                {
                    if (playerCharacter is LukeSkywalker luke)
                    {
                        luke.CaughtByEnemy();
                        
                        if (!luke.IsAlive())
                        {
                            isGameOver = true;
                            GameOver?.Invoke(this, EventArgs.Empty);
                            StopGame();
                        }
                        else
                        {
                            PlayerCaught?.Invoke(this, EventArgs.Empty);
                            
                        
                            MoveEnemiesAwayFromPlayer();
                        }
                    }
                    else if (playerCharacter is MasterYoda yoda)
                    {
                        yoda.CaughtByEnemy();
                        
                        if (!yoda.IsAlive())
                        {
                            isGameOver = true;
                            GameOver?.Invoke(this, EventArgs.Empty);
                            StopGame();
                        }
                        else
                        {
                            PlayerCaught?.Invoke(this, EventArgs.Empty);
                            
                            MoveEnemiesAwayFromPlayer();
                        }
                    }
                    
                    break;
                }
            }
        }
        
        private void MoveEnemiesAwayFromPlayer()
        {
            Random rand = new Random();
            
            foreach (Character enemy in evilCharacters)
            {
                int dx = rand.Next(-3, 4);
                int dy = rand.Next(-3, 4);
                
                int newX = enemy.GetLocation().GetX() + dx;
                int newY = enemy.GetLocation().GetY() + dy;
                
                if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
                {
                    if (maze[newX, newY] == 0)
                    {
                        enemy.GetLocation().SetX(newX);
                        enemy.GetLocation().SetY(newY);
                    }
                }
            }
        }
        
        public Character GetPlayerCharacter()
        {
            return playerCharacter;
        }
        
        public List<Character> GetEvilCharacters()
        {
            return evilCharacters;
        }
        
        public Location GetCupLocation()
        {
            return cupLocation;
        }
        
        public int[,] GetMaze()
        {
            return maze;
        }
        
        public int GetDistanceToNearestEnemy()
        {
            int minDistance = int.MaxValue;
            
            foreach (Character enemy in evilCharacters)
            {
                List<Location> path = enemy.ShortestPath(maze, playerCharacter.GetLocation());
                if (path.Count > 0 && path.Count < minDistance)
                {
                    minDistance = path.Count;
                }
            }
            
            return minDistance == int.MaxValue ? -1 : minDistance;
        }
    }
}
