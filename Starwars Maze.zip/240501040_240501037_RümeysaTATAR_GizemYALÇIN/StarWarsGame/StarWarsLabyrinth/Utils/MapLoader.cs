using System;
using System.Collections.Generic;
using System.IO;
using StarWarsLabyrinth.Models;
using StarWarsLabyrinth.Models.EvilCharacters;

namespace StarWarsLabyrinth.Utils
{
    public class MapLoader
    {
        private int[,] maze;
        
        private Dictionary<char, Location> entrances;
        
        private List<Character> evilCharacters;
        
        private Location playerStart;
        
        private Location cupLocation;

        public MapLoader()
        {
            entrances = new Dictionary<char, Location>();
            evilCharacters = new List<Character>();
        }

        public bool LoadMapFromFile(string filePath)
        {
            try
            {
                entrances.Clear();
                evilCharacters.Clear();
                
                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"HATA: Dosya bulunamadı: '{filePath}'");
                    return false;
                }

                string fileContent = File.ReadAllText(filePath);
                Console.WriteLine($"Dosya içeriği yüklendi. Boyut: {fileContent.Length} karakter");
                
                string[] lines = File.ReadAllLines(filePath);
                Console.WriteLine($"Satır sayısı: {lines.Length}");
                
                if (lines.Length < 3)
                {
                    Console.WriteLine("HATA: Harita dosyası eksik veya bozuk");
                    return false;
                }
                
                string[] dimensions = lines[0].Split(',');
                Console.WriteLine($"Boyut verisi: {lines[0]}");
                
                if (dimensions.Length != 2)
                {
                    Console.WriteLine("HATA: Geçersiz boyut formatı");
                    return false;
                }
                
                int rows = int.Parse(dimensions[0].Trim());
                int cols = int.Parse(dimensions[1].Trim());
                Console.WriteLine($"Satır sayısı: {rows}, Sütun sayısı: {cols}");
                
                if (rows <= 0 || cols <= 0 || rows + 3 >= lines.Length)
                {
                    Console.WriteLine("HATA: Geçersiz boyut değerleri");
                    return false;
                }
                
                maze = new int[rows, cols];
                
                for (int i = 0; i < rows; i++)
                {
                    if (i + 1 >= lines.Length)
                    {
                        Console.WriteLine($"HATA: Eksik satır: {i + 1}");
                        return false;
                    }
                    
                    string[] cells = lines[i + 1].Split(',');
                    if (cells.Length != cols)
                    {
                        Console.WriteLine($"HATA: Satır {i + 1}'de geçersiz sütun sayısı. Beklenen: {cols}, Bulunan: {cells.Length}");
                        return false;
                    }
                    
                    for (int j = 0; j < cols; j++)
                    {
                        maze[i, j] = int.Parse(cells[j].Trim());
                    }
                }
                
                if (rows + 1 >= lines.Length)
                {
                    Console.WriteLine("HATA: Oyuncu başlangıç konumu satırı eksik");
                    return false;
                }
                
                string[] playerPos = lines[rows + 1].Split(',');
                if (playerPos.Length != 2)
                {
                    Console.WriteLine("HATA: Geçersiz oyuncu konumu formatı");
                    return false;
                }
                
                int playerX = int.Parse(playerPos[0].Trim());
                int playerY = int.Parse(playerPos[1].Trim());
                playerStart = new Location(playerX, playerY);
                Console.WriteLine($"Oyuncu başlangıç konumu: {playerStart.GetX()}, {playerStart.GetY()}");
                
                if (rows + 2 >= lines.Length)
                {
                    Console.WriteLine("HATA: Kupa konumu satırı eksik");
                    return false;
                }
                
                string[] cupPos = lines[rows + 2].Split(',');
                if (cupPos.Length != 2)
                {
                    Console.WriteLine("HATA: Geçersiz kupa konumu formatı");
                    return false;
                }
                
                int cupX = int.Parse(cupPos[0].Trim());
                int cupY = int.Parse(cupPos[1].Trim());
                cupLocation = new Location(cupX, cupY);
                Console.WriteLine($"Kupa konumu: {cupLocation.GetX()}, {cupLocation.GetY()}");
                
                int lineIndex = rows + 3;
                Console.WriteLine("Giriş ve düşman verileri okunuyor...");
                
                while (lineIndex < lines.Length)
                {
                    string line = lines[lineIndex].Trim();
                    Console.WriteLine($"İşlenen satır: {line}");
                    
                    if (line.StartsWith("ENTRANCE:"))
                    {
                        string[] entranceData = line.Substring(9).Split(',');
                        if (entranceData.Length != 3)
                        {
                            Console.WriteLine($"HATA: Geçersiz giriş formatı: {line}");
                            lineIndex++;
                            continue;
                        }
                        
                        char entranceId = entranceData[0].Trim()[0];
                        int entranceX = int.Parse(entranceData[1].Trim());
                        int entranceY = int.Parse(entranceData[2].Trim());
                        entrances.Add(entranceId, new Location(entranceX, entranceY));
                        Console.WriteLine($"Giriş eklendi: {entranceId} ({entranceX}, {entranceY})");
                    }
                    else if (line.StartsWith("ENEMY:"))
                    {
                        string[] enemyData = line.Substring(6).Split(',');
                        if (enemyData.Length != 2)
                        {
                            Console.WriteLine($"HATA: Geçersiz düşman formatı: {line}");
                            lineIndex++;
                            continue;
                        }
                        
                        string enemyType = enemyData[0].Trim();
                        char entranceId = enemyData[1].Trim()[0];
                        
                        if (!entrances.ContainsKey(entranceId))
                        {
                            Console.WriteLine($"HATA: Giriş bulunamadı: {entranceId}");
                            lineIndex++;
                            continue;
                        }
                        
                        Location enemyLocation = entrances[entranceId];
                        
                        switch (enemyType)
                        {
                            case "Stormtrooper":
                                evilCharacters.Add(new Stormtrooper(enemyLocation.Clone()));
                                Console.WriteLine($"Stormtrooper eklendi: {entranceId} kapısında");
                                break;
                            case "DarthVader":
                                evilCharacters.Add(new DarthVader(enemyLocation.Clone()));
                                Console.WriteLine($"DarthVader eklendi: {entranceId} kapısında");
                                break;
                            case "KyloRen":
                                evilCharacters.Add(new KyloRen(enemyLocation.Clone()));
                                Console.WriteLine($"KyloRen eklendi: {entranceId} kapısında");
                                break;
                            default:
                                Console.WriteLine($"HATA: Bilinmeyen düşman tipi: {enemyType}");
                                break;
                        }
                    }
                    else if (!string.IsNullOrWhiteSpace(line))
                    {
                        Console.WriteLine($"Bilinmeyen satır tipi: {line}");
                    }
                    lineIndex++;
                }
                
                Console.WriteLine($"Harita başarıyla yüklendi! Labirent boyutu: {maze.GetLength(0)}x{maze.GetLength(1)}, Giriş sayısı: {entrances.Count}, Düşman sayısı: {evilCharacters.Count}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Harita yüklenirken hata: {ex.Message}");
                Console.WriteLine($"Yığın izleme: {ex.StackTrace}");
                return false;
            }
        }

        public int[,] GetMaze()
        {
            return maze;
        }
        
        public Dictionary<char, Location> GetEntrances()
        {
            return entrances;
        }
        
        public List<Character> GetEvilCharacters()
        {
            return evilCharacters;
        }
        
        public Location GetPlayerStart()
        {
            return playerStart;
        }
        
        public Location GetCupLocation()
        {
            return cupLocation;
        }
        
        public static void CreateDefaultMapFile(string filePath)
        {
            const int rows = 15;
            const int cols = 15;
            
            List<string> lines = new List<string>();
            
            lines.Add($"{rows},{cols}");
            
            int[,] maze = new int[rows, cols];
            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    if (i == 0 || i == rows - 1 || j == 0 || j == cols - 1)
                    {
                        maze[i, j] = 1; // Duvar
                    }
                }
            }
            
            Random rand = new Random();
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    if (rand.Next(100) < 30) 
                    {
                        maze[i, j] = 1;
                    }
                }
            }
            
            maze[5, 6] = 0;
            for (int i = 4; i <= 6; i++)
            {
                for (int j = 5; j <= 7; j++)
                {
                    maze[i, j] = 0;
                }
            }
            
            maze[rows - 3, cols - 3] = 0;

            maze[1, cols / 2] = 0;

            maze[rows / 2, 1] = 0;

            maze[rows - 2, cols / 2] = 0;
            
            for (int i = 0; i < rows; i++)
            {
                string row = "";
                for (int j = 0; j < cols; j++)
                {
                    row += maze[i, j];
                    if (j < cols - 1)
                        row += ",";
                }
                lines.Add(row);
            }
            
            lines.Add("5,6");
            
            lines.Add($"{rows - 3},{cols - 3}");
            
            lines.Add("ENTRANCE:A,1," + (cols / 2).ToString());
            lines.Add("ENTRANCE:B," + (rows / 2).ToString() + ",1");
            lines.Add("ENTRANCE:C," + (rows - 2).ToString() + "," + (cols / 2).ToString());
            
            lines.Add("ENEMY:Stormtrooper,A");
            lines.Add("ENEMY:DarthVader,B");
            lines.Add("ENEMY:KyloRen,C");
            
            File.WriteAllLines(filePath, lines);
        }
    }
}
