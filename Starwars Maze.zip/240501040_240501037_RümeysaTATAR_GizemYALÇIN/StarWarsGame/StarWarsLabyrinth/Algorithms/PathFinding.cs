using System;
using System.Collections.Generic;
using StarWarsLabyrinth.Models;

namespace StarWarsLabyrinth.Algorithms
{
    public class PathFinding
    {
        public static List<Location> BFS(int[,] maze, Location start, Location target)
        {
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            
            bool[,] visited = new bool[rows, cols];
            Location[,] parent = new Location[rows, cols];
            
            Queue<Location> queue = new Queue<Location>();
            queue.Enqueue(start);
            visited[start.GetX(), start.GetY()] = true;
            
            int[] dx = { -1, 0, 1, 0 };
            int[] dy = { 0, 1, 0, -1 };
            
            bool foundPath = false;
            
            while (queue.Count > 0 && !foundPath)
            {
                Location current = queue.Dequeue();
                
                if (current.GetX() == target.GetX() && current.GetY() == target.GetY())
                {
                    foundPath = true;
                    continue;
                }
                
                for (int i = 0; i < 4; i++)
                {
                    int newX = current.GetX() + dx[i];
                    int newY = current.GetY() + dy[i];
                    
                    if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
                    {
                        if (!visited[newX, newY] && maze[newX, newY] == 0)
                        {
                            Location nextLocation = new Location(newX, newY);
                            queue.Enqueue(nextLocation);
                            visited[newX, newY] = true;
                            parent[newX, newY] = current;
                        }
                    }
                }
            }
            
            List<Location> path = new List<Location>();
            
            if (foundPath)
            {
                Location current = target;
                while (!(current.GetX() == start.GetX() && current.GetY() == start.GetY()))
                {
                    path.Add(current);
                    current = parent[current.GetX(), current.GetY()];
                }
                path.Add(start);
                path.Reverse();
            }
            
            return path;
        }
        
        public static List<Location> Dijkstra(int[,] maze, Location start, Location target)
        {
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            
            int[,] distance = new int[rows, cols];
            bool[,] visited = new bool[rows, cols];
            Location[,] parent = new Location[rows, cols];
            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    distance[i, j] = int.MaxValue;
                }
            }
            
            distance[start.GetX(), start.GetY()] = 0;
            
            int[] dx = { -1, 0, 1, 0 };
            int[] dy = { 0, 1, 0, -1 };
            
            for (int count = 0; count < rows * cols - 1; count++)
            {
                int minDist = int.MaxValue;
                Location current = new Location(-1, -1);
                bool foundPoint = false;
                
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < cols; j++)
                    {
                        if (!visited[i, j] && distance[i, j] < minDist && maze[i, j] == 0)
                        {
                            minDist = distance[i, j];
                            current = new Location(i, j);
                            foundPoint = true;
                        }
                    }
                }
                
                if (!foundPoint)
                    break;
                
                int x = current.GetX();
                int y = current.GetY();
                
                visited[x, y] = true;
                
                if (x == target.GetX() && y == target.GetY())
                    break;
                
                for (int i = 0; i < 4; i++)
                {
                    int newX = x + dx[i];
                    int newY = y + dy[i];
                    
                    if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
                    {
                        if (!visited[newX, newY] && maze[newX, newY] == 0)
                        {
                            if (distance[x, y] + 1 < distance[newX, newY])
                            {
                                distance[newX, newY] = distance[x, y] + 1;
                                parent[newX, newY] = current;
                            }
                        }
                    }
                }
            }
            
            List<Location> path = new List<Location>();
            
            if (distance[target.GetX(), target.GetY()] != int.MaxValue)
            {
                Location current = target;
                while (!(current.GetX() == start.GetX() && current.GetY() == start.GetY()))
                {
                    path.Add(current);
                    current = parent[current.GetX(), current.GetY()];
                }
                path.Add(start);
                path.Reverse();
            }
            
            return path;
        }
        
        public static List<Location> AStar(int[,] maze, Location start, Location target)
        {
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            
            List<AStarNode> openList = new List<AStarNode>();
            HashSet<string> closedList = new HashSet<string>();
            
            AStarNode startNode = new AStarNode(start, new AStarNode(start, null, 0, 0), 0, ManhattanDistance(start, target));
            openList.Add(startNode);
            
            int[] dx = { -1, 0, 1, 0 };
            int[] dy = { 0, 1, 0, -1 };
            
            while (openList.Count > 0)
            {
                openList.Sort((a, b) => a.f.CompareTo(b.f));
                AStarNode current = openList[0];
                openList.RemoveAt(0);
                
                string key = $"{current.location.GetX()},{current.location.GetY()}";
                closedList.Add(key);
                
                if (current.location.GetX() == target.GetX() && current.location.GetY() == target.GetY())
                {
                    List<Location> path = new List<Location>();
                    while (current != null && current.parent != null)
                    {
                        path.Add(current.location);
                        current = current.parent;
                    }
                    path.Reverse();
                    return path;
                }
                
                for (int i = 0; i < 4; i++)
                {
                    int newX = current.location.GetX() + dx[i];
                    int newY = current.location.GetY() + dy[i];
                    
                    if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
                    {
                        if (maze[newX, newY] == 0)
                        {
                            Location neighborLoc = new Location(newX, newY);
                            string neighborKey = $"{newX},{newY}";
                            
                            if (closedList.Contains(neighborKey))
                                continue;
                                
                            int g = current.g + 1;
                            int h = ManhattanDistance(neighborLoc, target);
                            int f = g + h;
                            
                            bool inOpenList = false;
                            foreach (var node in openList)
                            {
                                if (node.location.GetX() == newX && node.location.GetY() == newY)
                                {
                                    inOpenList = true;
                                    if (g < node.g)
                                    {
                                        node.g = g;
                                        node.f = g + h;
                                        node.parent = current;
                                    }
                                    break;
                                }
                            }
                            
                            if (!inOpenList)
                            {
                                AStarNode newNode = new AStarNode(neighborLoc, current, g, h);
                                openList.Add(newNode);
                            }
                        }
                    }
                }
            }
            
            return new List<Location>();
        }
        
        private static int ManhattanDistance(Location a, Location b)
        {
            return Math.Abs(a.GetX() - b.GetX()) + Math.Abs(a.GetY() - b.GetY());
        }
        
        private class AStarNode
        {
            public Location location;
            public AStarNode parent;
            public int g;
            public int h;
            public int f;
            
            public AStarNode(Location location, AStarNode parent, int g, int h)
            {
                this.location = location;
                this.parent = parent;
                this.g = g;
                this.h = h;
                this.f = g + h;
            }
        }
    }
}
