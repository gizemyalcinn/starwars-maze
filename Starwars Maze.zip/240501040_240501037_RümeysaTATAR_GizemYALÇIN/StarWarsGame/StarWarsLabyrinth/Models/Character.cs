using System;
using System.Collections.Generic;

namespace StarWarsLabyrinth.Models
{
    public class Character
    {
        private string name;
        private string type;
        private Location location;

        public Character(string name, string type, Location location)
        {
            this.name = name;
            this.type = type;
            this.location = location;
        }

        public string GetName()
        {
            return name;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public string GetType()
        {
            return type;
        }

        public void SetType(string type)
        {
            this.type = type;
        }

        public Location GetLocation()
        {
            return location;
        }

        public void SetLocation(Location location)
        {
            this.location = location;
        }

       public virtual List<Location> ShortestPath(int[,] maze, Location target)
        {
            return new List<Location>();
        }
    }
}
