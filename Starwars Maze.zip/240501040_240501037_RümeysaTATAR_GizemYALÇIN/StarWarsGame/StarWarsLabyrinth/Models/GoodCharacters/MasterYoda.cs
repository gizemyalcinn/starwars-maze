using System;

namespace StarWarsLabyrinth.Models.GoodCharacters
{
    public class MasterYoda : Character
    {
        private double health;

        public MasterYoda(Location location) : base("Master Yoda", "Good", location)
        {
            health = 3.0;
        }

        public double GetHealth()
        {
            return health;
        }

        public void SetHealth(double health)
        {
            this.health = health;
        }

        public void CaughtByEnemy()
        {
            if (health > 0)
            {
                health -= 0.5;
            }
        }

        public bool IsAlive()
        {
            return health > 0;
        }
    }
}
