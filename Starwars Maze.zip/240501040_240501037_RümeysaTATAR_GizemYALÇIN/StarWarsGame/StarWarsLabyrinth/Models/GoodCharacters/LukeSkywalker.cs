using System;

namespace StarWarsLabyrinth.Models.GoodCharacters
{
    public class LukeSkywalker : Character
    {
        private int health;

        public LukeSkywalker(Location location) : base("Luke Skywalker", "Good", location)
        {
            health = 3;
        }

        public int GetHealth()
        {
            return health;
        }

        public void SetHealth(int health)
        {
            this.health = health;
        }

        public void CaughtByEnemy()
        {
            if (health > 0)
            {
                health--;
            }
        }

        public bool IsAlive()
        {
            return health > 0;
        }
    }
}
