using System;

namespace StarWarsLabyrinth.Models
{
    public class Location
    {
        private int x;
        private int y;

        public Location(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int GetX()
        {
            return x;
        }

        public int GetY()
        {
            return y;
        }

        public void SetX(int newX)
        {
            x = newX;
        }

        public void SetY(int newY)
        {
            y = newY;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            Location other = (Location)obj;
            return x == other.x && y == other.y;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(x, y);
        }

        public Location Clone()
        {
            return new Location(x, y);
        }
        
        public override string ToString()
        {
            return $"({x}, {y})";
        }
    }
}
