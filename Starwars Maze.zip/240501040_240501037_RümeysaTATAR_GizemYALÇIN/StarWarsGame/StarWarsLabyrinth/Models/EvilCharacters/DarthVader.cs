using System;
using System.Collections.Generic;
using StarWarsLabyrinth.Algorithms;

namespace StarWarsLabyrinth.Models.EvilCharacters
{
    public class DarthVader : Character
    {
        public DarthVader(Location location) : base("Darth Vader", "Evil", location)
        {

        }

        public override List<Location> ShortestPath(int[,] maze, Location target)
        {
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            
            int[,] modifiedMaze = new int[rows, cols];
            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    modifiedMaze[i, j] = 0;
                }
            }
            
            return PathFinding.AStar(modifiedMaze, this.GetLocation(), target);
        }
    }
}
