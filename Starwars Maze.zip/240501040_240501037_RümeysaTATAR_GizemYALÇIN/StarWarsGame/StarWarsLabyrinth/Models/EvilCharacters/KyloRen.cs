using System;
using System.Collections.Generic;
using StarWarsLabyrinth.Algorithms;

namespace StarWarsLabyrinth.Models.EvilCharacters
{
    public class KyloRen : Character
    {
        public KyloRen(Location location) : base("Kylo Ren", "Evil", location)
        {
        }

        public override List<Location> ShortestPath(int[,] maze, Location target)
        {
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            
            bool[,] visited = new bool[rows, cols];
            Location[,] parent = new Location[rows, cols];
            
            Queue<Location> queue = new Queue<Location>();
            queue.Enqueue(this.GetLocation());
            visited[this.GetLocation().GetX(), this.GetLocation().GetY()] = true;
            
            int[] dx = { -1, 0, 1, 0 };
            int[] dy = { 0, 1, 0, -1 };
            
            bool foundPath = false;
            
            while (queue.Count > 0 && !foundPath)
            {
                Location current = queue.Dequeue();
                
                if (current.GetX() == target.GetX() && current.GetY() == target.GetY())
                {
                    foundPath = true;
                    continue;
                }
                
                for (int i = 0; i < 4; i++)
                {
                    for (int step = 1; step <= 2; step++)
                    {
                        int newX = current.GetX() + dx[i] * step;
                        int newY = current.GetY() + dy[i] * step;
                        
                        if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
                        {
                            if (!visited[newX, newY] && maze[newX, newY] == 0)
                            {
                                if (step == 2)
                                {
                                    int midX = current.GetX() + dx[i];
                                    int midY = current.GetY() + dy[i];
                                    
                                    if (maze[midX, midY] == 1)
                                        continue;
                                }
                                
                                Location nextLocation = new Location(newX, newY);
                                queue.Enqueue(nextLocation);
                                visited[newX, newY] = true;
                                parent[newX, newY] = current;
                            }
                        }
                    }
                }
            }
            
            List<Location> fullPath = new List<Location>();

            if (foundPath)
            {
                Location current = target;
                while (current != null && !(current.GetX() == this.GetLocation().GetX() && current.GetY() == this.GetLocation().GetY()))
                {
                    fullPath.Add(current);
                    Location nextParent = parent[current.GetX(), current.GetY()];
                    if (nextParent == null && !(current.GetX() == this.GetLocation().GetX() && current.GetY() == this.GetLocation().GetY()))
                    {
                        Console.Error.WriteLine("Error: Path reconstruction failed unexpectedly.");
                        return new List<Location>();
                    }
                    current = nextParent;
                }
                if (current != null) {
                    fullPath.Add(this.GetLocation());
                } else if (fullPath.Count == 0 && target.GetX() == this.GetLocation().GetX() && target.GetY() == this.GetLocation().GetY()) {
                    fullPath.Add(this.GetLocation());
                }

                if (fullPath.Count > 0) {
                    fullPath.Reverse();
                } else if (foundPath) {
                     fullPath.Add(this.GetLocation());
                }
            } else {
                 fullPath.Add(this.GetLocation());
                 return fullPath;
            }

            if (fullPath.Count > 1)
            {
                return new List<Location> { fullPath[0], fullPath[1] };
            }
            else
            {
                return fullPath;
            }
        }
    }
}
