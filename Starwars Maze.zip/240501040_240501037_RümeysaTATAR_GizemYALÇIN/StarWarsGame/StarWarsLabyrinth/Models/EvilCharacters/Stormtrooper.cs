using System;
using System.Collections.Generic;
using StarWarsLabyrinth.Algorithms;

namespace StarWarsLabyrinth.Models.EvilCharacters
{
    public class Stormtrooper : Character
    {
        public Stormtrooper(Location location) : base("Stormtrooper", "Evil", location)
        {
        }

        public override List<Location> ShortestPath(int[,] maze, Location target)
        {
            return PathFinding.BFS(maze, this.GetLocation(), target);
        }
    }
}
