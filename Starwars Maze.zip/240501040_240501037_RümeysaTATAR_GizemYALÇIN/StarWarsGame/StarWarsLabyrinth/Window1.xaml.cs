﻿﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;
using System.Media;
using StarWarsLabyrinth.Models;
using StarWarsLabyrinth.Models.GoodCharacters;
using StarWarsLabyrinth.Models.EvilCharacters;
using StarWarsLabyrinth.Utils;

namespace StarWarsLabyrinth
{
    public partial class Window1 : Window
    {
        private GameEngine gameEngine;
        private MapLoader mapLoader;

        private int[,] maze;

        private double cellSize;

        private Character playerCharacter;

        private Location cupLocation;

        private DispatcherTimer renderTimer;
        
        private Grid characterSelectionPanel;
        private Grid gamePanel;
        private Grid gameOverPanel;
        private Canvas gameCanvas;
        private TextBlock characterNameText;
        private StackPanel healthPanel;
        private TextBlock nearestEnemyText;
        private TextBlock statusText;
        private TextBlock gameOverText;
        private TextBlock gameOverScoreText;

        public Window1()
        {
            this.Title = "Star Wars Labirent Oyunu";
            this.Width = 900;
            this.Height = 700;
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            this.KeyDown += Window_KeyDown;
            
            InitializeUI();
            
            gameEngine = new GameEngine();
            mapLoader = new MapLoader();
            
            gameEngine.PlayerMoved += OnPlayerMoved;
            gameEngine.EnemiesMoved += OnEnemiesMoved;
            gameEngine.PlayerCaught += OnPlayerCaught;
            gameEngine.GameOver += OnGameOver;
            gameEngine.GameWon += OnGameWon;
            
            renderTimer = new DispatcherTimer();
            renderTimer.Tick += OnRenderTimerTick;
            renderTimer.Interval = TimeSpan.FromMilliseconds(100);
            
            string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string exeDir = System.IO.Path.GetDirectoryName(exePath);
            Console.WriteLine($"Uygulama çalışma dizini: {exeDir}");

            string assetsDir = System.IO.Path.Combine(exeDir, "Assets");
            string mapFilePath = System.IO.Path.Combine(assetsDir, "harita.txt");
            
            Console.WriteLine($"Harita dosya yolu: {mapFilePath}");
            
            if (!Directory.Exists(assetsDir))
            {
                Console.WriteLine($"Assets dizini oluşturuluyor: {assetsDir}");
                Directory.CreateDirectory(assetsDir);
            }
            
            if (!File.Exists(mapFilePath))
            {
                Console.WriteLine($"Harita dosyası oluşturuluyor: {mapFilePath}");
                MapLoader.CreateDefaultMapFile(mapFilePath);
            }
            
            if (File.Exists(mapFilePath))
            {
                Console.WriteLine($"Harita dosyası mevcut: {mapFilePath}");
                Console.WriteLine($"Dosya boyutu: {new FileInfo(mapFilePath).Length} byte");
            }
            else
            {
                Console.WriteLine($"HATA: Harita dosyası oluşturulamadı: {mapFilePath}");
            }
            
            characterSelectionPanel.Visibility = Visibility.Visible;
            gamePanel.Visibility = Visibility.Collapsed;
            gameOverPanel.Visibility = Visibility.Collapsed;
        }

        private void InitializeUI()
        {
            Grid mainGrid = new Grid();
            mainGrid.Background = new SolidColorBrush(Colors.Black);
            this.Content = mainGrid;
            
            RowDefinition headerRow = new RowDefinition { Height = GridLength.Auto };
            RowDefinition contentRow = new RowDefinition { Height = new GridLength(1, GridUnitType.Star) };
            RowDefinition footerRow = new RowDefinition { Height = GridLength.Auto };
            mainGrid.RowDefinitions.Add(headerRow);
            mainGrid.RowDefinitions.Add(contentRow);
            mainGrid.RowDefinitions.Add(footerRow);
            
            TextBlock headerText = new TextBlock
            {
                Text = "STAR WARS LABİRENT",
                FontFamily = new FontFamily("Arial Black"),
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 232, 31)),
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 10, 0, 20)
            };
            Grid.SetRow(headerText, 0);
            mainGrid.Children.Add(headerText);
            
            Grid contentGrid = new Grid();
            Grid.SetRow(contentGrid, 1);
            mainGrid.Children.Add(contentGrid);
            
            characterSelectionPanel = CreateCharacterSelectionPanel();
            contentGrid.Children.Add(characterSelectionPanel);
            
            gamePanel = CreateGamePanel();
            contentGrid.Children.Add(gamePanel);
            
            Border statusBorder = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                BorderThickness = new Thickness(2),
                Margin = new Thickness(20, 0, 20, 20),
                CornerRadius = new CornerRadius(5)
            };
            Grid.SetRow(statusBorder, 2);
            mainGrid.Children.Add(statusBorder);
            
            statusText = new TextBlock
            {
                Text = "Oyuna başlamak için bir karakter seçin.",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 16,
                Padding = new Thickness(15),
                TextAlignment = TextAlignment.Center
            };
            statusBorder.Child = statusText;
            
            gameOverPanel = CreateGameOverPanel();
            Grid.SetRow(gameOverPanel, 1);
            mainGrid.Children.Add(gameOverPanel);
        }
        
        private Grid CreateCharacterSelectionPanel()
        {
            Grid panel = new Grid();
            
            StackPanel content = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            panel.Children.Add(content);
            
            TextBlock title = new TextBlock
            {
                Text = "Karakterinizi Seçin",
                FontFamily = new FontFamily("Arial Black"),
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 232, 31)),
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 0, 0, 40)
            };
            content.Children.Add(title);
            
            Grid characterGrid = new Grid();
            characterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            characterGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            content.Children.Add(characterGrid);
            
            StackPanel lukePanel = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            Grid.SetColumn(lukePanel, 0);
            characterGrid.Children.Add(lukePanel);
            
            Border lukeBorder = new Border
            {
                Width = 200,
                Height = 200,
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(10),
                Margin = new Thickness(20)
            };
            lukePanel.Children.Add(lukeBorder);
            
            Image lukeImage = new Image
            {
                Source = new BitmapImage(new Uri("Images/LukeSkywalker.png", UriKind.Relative)),
                Stretch = Stretch.Uniform,
                Width = 150,
                Height = 150
            };
            lukeBorder.Child = lukeImage;
            
            TextBlock lukeDesc = new TextBlock
            {
                Text = "3 can hakkı vardır",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 5, 0, 5)
            };
            lukePanel.Children.Add(lukeDesc);
            
            Button lukeButton = CreateStyledButton("Luke Skywalker'ı Seç", 200);
            lukeButton.Click += SelectLukeSkywalker_Click;
            lukePanel.Children.Add(lukeButton);
            
            StackPanel yodaPanel = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            Grid.SetColumn(yodaPanel, 1);
            characterGrid.Children.Add(yodaPanel);
            
            Border yodaBorder = new Border
            {
                Width = 200,
                Height = 200,
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(10),
                Margin = new Thickness(20)
            };
            yodaPanel.Children.Add(yodaBorder);
            
            Image yodaImage = new Image
            {
                Source = new BitmapImage(new Uri("Images/MasterYoda.png", UriKind.Relative)),
                Stretch = Stretch.Uniform,
                Width = 150,
                Height = 150
            };
            yodaBorder.Child = yodaImage;
            
            TextBlock yodaDesc = new TextBlock
            {
                Text = "Yakalandığında canının yarısını kaybeder",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 5, 0, 5)
            };
            yodaPanel.Children.Add(yodaDesc);
            
            Button yodaButton = CreateStyledButton("Master Yoda'yı Seç", 200);
            yodaButton.Click += SelectMasterYoda_Click;
            yodaPanel.Children.Add(yodaButton);
            
            return panel;
        }
        
        private Grid CreateGamePanel()
        {
            Grid panel = new Grid { Visibility = Visibility.Collapsed };
            
            panel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            panel.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            
            Border canvasBorder = new Border
            {
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                BorderThickness = new Thickness(2),
                Margin = new Thickness(20),
                CornerRadius = new CornerRadius(10),
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34))
            };
            Grid.SetColumn(canvasBorder, 0);
            panel.Children.Add(canvasBorder);
            
            gameCanvas = new Canvas
            {
                Width = 500,
                Height = 500,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            canvasBorder.Child = gameCanvas;
            
            StackPanel infoPanel = new StackPanel
            {
                Margin = new Thickness(0, 20, 20, 20),
                MinWidth = 220
            };
            Grid.SetColumn(infoPanel, 1);
            panel.Children.Add(infoPanel);
            
            Border infoBorder = new Border
            {
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(10),
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34)),
                Padding = new Thickness(10)
            };
            infoPanel.Children.Add(infoBorder);
            
            StackPanel infoContent = new StackPanel();
            infoBorder.Child = infoContent;
            
            TextBlock infoTitle = new TextBlock
            {
                Text = "Oyun Bilgileri",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 232, 31)),
                Margin = new Thickness(0, 0, 0, 10),
                TextAlignment = TextAlignment.Center
            };
            infoContent.Children.Add(infoTitle);
            
            TextBlock characterLabel = new TextBlock
            {
                Text = "Karakter:",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(characterLabel);
            
            characterNameText = new TextBlock
            {
                Text = "-",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(characterNameText);
            
            TextBlock healthLabel = new TextBlock
            {
                Text = "Sağlık:",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 10, 10, 0)
            };
            infoContent.Children.Add(healthLabel);
            
            healthPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(10, 5, 10, 5)
            };
            infoContent.Children.Add(healthPanel);
            
            Rectangle separator1 = new Rectangle
            {
                Height = 1,
                Fill = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                Margin = new Thickness(10, 10, 10, 10)
            };
            infoContent.Children.Add(separator1);
            
            TextBlock enemyLabel = new TextBlock
            {
                Text = "En Yakın Düşman Mesafesi:",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(enemyLabel);
            
            nearestEnemyText = new TextBlock
            {
                Text = "-",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(nearestEnemyText);
            
            Rectangle separator2 = new Rectangle
            {
                Height = 1,
                Fill = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                Margin = new Thickness(10, 10, 10, 10)
            };
            infoContent.Children.Add(separator2);
            
            TextBlock controlsLabel = new TextBlock
            {
                Text = "Kontroller:",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 5, 10, 3)
            };
            infoContent.Children.Add(controlsLabel);
            
            TextBlock upKey = new TextBlock
            {
                Text = "↑ - Yukarı",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(upKey);
            
            TextBlock downKey = new TextBlock
            {
                Text = "↓ - Aşağı",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(downKey);
            
            TextBlock leftKey = new TextBlock
            {
                Text = "← - Sol",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(leftKey);
            
            TextBlock rightKey = new TextBlock
            {
                Text = "→ - Sağ",
                Foreground = new SolidColorBrush(Colors.White),
                FontSize = 14,
                Margin = new Thickness(10, 3, 10, 3)
            };
            infoContent.Children.Add(rightKey);
            
            Button newGameButton = CreateStyledButton("Yeni Oyun", 0);
            newGameButton.Margin = new Thickness(10, 20, 10, 10);
            newGameButton.Click += NewGame_Click;
            infoContent.Children.Add(newGameButton);
            
            return panel;
        }
        
        private Grid CreateGameOverPanel()
        {
            Grid panel = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(153, 0, 0, 0)),
                Visibility = Visibility.Collapsed
            };
            
            Border border = new Border
            {
                Width = 400,
                Height = 250,
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68)),
                BorderThickness = new Thickness(3),
                CornerRadius = new CornerRadius(15),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            panel.Children.Add(border);
            
            StackPanel content = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            border.Child = content;
            
            gameOverText = new TextBlock
            {
                Text = "OYUN BİTTİ!",
                FontSize = 32,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Colors.Red),
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 20, 0, 30)
            };
            content.Children.Add(gameOverText);
            
            gameOverScoreText = new TextBlock
            {
                Text = "Puan: 0",
                FontSize = 18,
                Foreground = new SolidColorBrush(Colors.White),
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 0, 0, 30)
            };
            content.Children.Add(gameOverScoreText);
            
            Button playAgainButton = CreateStyledButton("Yeniden Oyna", 200);
            playAgainButton.Click += PlayAgain_Click;
            content.Children.Add(playAgainButton);
            
            return panel;
        }
        
        private Button CreateStyledButton(string content, double width)
        {
            Button button = new Button
            {
                Content = content,
                Background = new SolidColorBrush(Color.FromRgb(34, 34, 34)),
                Foreground = new SolidColorBrush(Color.FromRgb(255, 232, 31)),
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(15, 8, 15, 8),
                Margin = new Thickness(10),
                BorderThickness = new Thickness(2),
                BorderBrush = new SolidColorBrush(Color.FromRgb(68, 68, 68))
            };
            
            if (width > 0)
            {
                button.Width = width;
            }
            
            return button;
        }

        private void SelectLukeSkywalker_Click(object sender, RoutedEventArgs e)
        {
            StartGameWithCharacter(new LukeSkywalker(new Location(0, 0)));
            characterNameText.Text = "Luke Skywalker";
            UpdateHealthDisplay();
        }

        private void SelectMasterYoda_Click(object sender, RoutedEventArgs e)
        {
            StartGameWithCharacter(new MasterYoda(new Location(0, 0)));
            characterNameText.Text = "Master Yoda";
            UpdateHealthDisplay();
        }

        private void StartGameWithCharacter(Character character)
        {
            playerCharacter = character;
            
            try {
                string directPath = "Assets/harita.txt";
                if (File.Exists(directPath)) {
                    Console.WriteLine($"Harita dosyası mevcut: {directPath}");
                    
                    string fileContent = File.ReadAllText(directPath);
                    Console.WriteLine($"Dosya içeriği: {fileContent.Substring(0, Math.Min(100, fileContent.Length))}...");
                    
                    string[] lines = File.ReadAllLines(directPath);
                    Console.WriteLine($"Satır sayısı: {lines.Length}");
                    if (lines.Length > 0) {
                        Console.WriteLine($"İlk satır: {lines[0]}");
                    }
                    
                    bool mapLoaded = mapLoader.LoadMapFromFile(directPath);
                    if (!mapLoaded) {
                        Console.WriteLine($"Assets/harita.txt mevcut ama yüklenemedi! ({lines.Length} satır)");
                    }
                    else {
                        CompleteGameSetup();
                        return;
                    }
                }
                else {
                    Console.WriteLine($"Assets/harita.txt dosyası bulunamadı");
                }
                
                string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string exeDir = System.IO.Path.GetDirectoryName(exePath);
                string mapFilePath = System.IO.Path.Combine(exeDir, "Assets", "harita.txt");
                
                if (File.Exists(mapFilePath)) {
                    Console.WriteLine($"Harita dosyası mevcut: {mapFilePath}");
                    
                    string fileContent = File.ReadAllText(mapFilePath);
                    Console.WriteLine($"Dosya içeriği: {fileContent.Substring(0, Math.Min(100, fileContent.Length))}...");
                    
                    string[] lines = File.ReadAllLines(mapFilePath);
                    Console.WriteLine($"Satır sayısı: {lines.Length}");
                    if (lines.Length > 0) {
                        Console.WriteLine($"İlk satır: {lines[0]}");
                    }
                    
                    bool mapLoaded = mapLoader.LoadMapFromFile(mapFilePath);
                    if (!mapLoaded) {
                        Console.WriteLine($"{mapFilePath} mevcut ama yüklenemedi!");
                    }
                    else {
                        CompleteGameSetup();
                        return;
                    }
                }
                else {
                    Console.WriteLine($"Harita dosyası bulunamadı: {mapFilePath}");
                    Console.WriteLine($"Exe dizini: {exeDir}");
                    
                    if (Directory.Exists(System.IO.Path.Combine(exeDir, "Assets"))) {
                        Console.WriteLine($"Assets dizini mevcut. İçindeki dosyalar:");
                        foreach (var file in Directory.GetFiles(System.IO.Path.Combine(exeDir, "Assets"))) {
                            Console.WriteLine($"  - {System.IO.Path.GetFileName(file)}");
                        }
                    }
                    else {
                        Console.WriteLine($"Assets dizini bulunamadı: {System.IO.Path.Combine(exeDir, "Assets")}");
                    }
                }
                
                string tempPath = System.IO.Path.Combine(exeDir, "harita_temp.txt");
                Console.WriteLine($"Geçici harita dosyası oluşturuluyor: {tempPath}");
                
                MapLoader.CreateDefaultMapFile(tempPath);
                
                if (File.Exists(tempPath)) {
                    Console.WriteLine($"Geçici harita dosyası oluşturuldu: {tempPath}");
                    bool mapLoaded = mapLoader.LoadMapFromFile(tempPath);
                    if (!mapLoaded) {
                        Console.WriteLine($"Geçici harita dosyası oluşturuldu ama yüklenemedi: {tempPath}");
                        return;
                    }
                    else {
                        CompleteGameSetup();
                        return;
                    }
                }
                else {
                    Console.WriteLine($"Geçici harita dosyası oluşturulamadı: {tempPath}");
                    return;
                }
            }
            catch (Exception ex) {
                MessageBox.Show($"Hata oluştu: {ex.Message}\n\nStack trace: {ex.StackTrace}", "Kritik Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }
        
        private void CompleteGameSetup()
        {
            
            maze = mapLoader.GetMaze();
            playerCharacter.SetLocation(mapLoader.GetPlayerStart().Clone());
            cupLocation = mapLoader.GetCupLocation().Clone();
            
            gameEngine.SetMaze(maze);
            gameEngine.SetPlayerCharacter(playerCharacter);
            gameEngine.SetEvilCharacters(mapLoader.GetEvilCharacters());
            gameEngine.SetCupLocation(cupLocation);
            
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            cellSize = Math.Min(gameCanvas.Width / cols, gameCanvas.Height / rows);
            
            characterSelectionPanel.Visibility = Visibility.Collapsed;
            gamePanel.Visibility = Visibility.Visible;
            statusText.Text = "Oyun başladı! Klavye ok tuşlarını kullanarak karakteri yönlendirin.";
            
            DrawMaze();
            
            renderTimer.Start();
            
            gameEngine.StartGame();
        }

        private void NewGame_Click(object sender, RoutedEventArgs e)
        {
            gameEngine.StopGame();
            renderTimer.Stop();
            
            characterSelectionPanel.Visibility = Visibility.Visible;
            gamePanel.Visibility = Visibility.Collapsed;
            gameOverPanel.Visibility = Visibility.Collapsed;
            
            statusText.Text = "Oyuna başlamak için bir karakter seçin.";
        }

        private void PlayAgain_Click(object sender, RoutedEventArgs e)
        {
            gameOverPanel.Visibility = Visibility.Collapsed;
            NewGame_Click(sender, e);
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (gamePanel.Visibility != Visibility.Visible)
                return;
                
            switch (e.Key)
            {
                case Key.Up:
                    gameEngine.MovePlayer(-1, 0);
                    break;
                case Key.Down:
                    gameEngine.MovePlayer(1, 0);
                    break;
                case Key.Left:
                    gameEngine.MovePlayer(0, -1);
                    break;
                case Key.Right:
                    gameEngine.MovePlayer(0, 1);
                    break;
            }
        }

        private void OnPlayerMoved(object sender, EventArgs e)
        {
            UpdateEnemyDistanceDisplay();
        }

        private void OnEnemiesMoved(object sender, EventArgs e)
        {
            UpdateEnemyDistanceDisplay();
        }

        private void OnPlayerCaught(object sender, EventArgs e)
        {
            PlayCaptureSound();
            
            UpdateHealthDisplay();
            
            statusText.Text = "Dikkat! Bir düşman seni yakaladı!";
        }
        
        private void PlayCaptureSound()
        {
            try
            {
                string exePath = AppDomain.CurrentDomain.BaseDirectory;
                string soundPath = System.IO.Path.Combine(exePath, "Sounds", "CaptureSound.wav");
                
                if (System.IO.File.Exists(soundPath))
                {
                    Console.WriteLine($"Ses dosyası bulundu: {soundPath}");
                    SoundPlayer soundPlayer = new SoundPlayer(soundPath);
                    soundPlayer.LoadAsync();
                    soundPlayer.Play();
                }
                else
                {
                    Console.WriteLine($"HATA: Ses dosyası bulunamadı: {soundPath}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ses çalma hatası: {ex.Message}");
            }
        }

        private void OnGameOver(object sender, EventArgs e)
        {
            gameOverPanel.Visibility = Visibility.Visible;
            gameOverText.Text = "OYUN BİTTİ!";
            gameOverText.Foreground = new SolidColorBrush(Colors.Red);
            gameOverScoreText.Text = "";
            
            statusText.Text = "Oyun bitti! Tüm canlarını kaybettin.";
        }

        private void OnGameWon(object sender, EventArgs e)
        {
            gameOverPanel.Visibility = Visibility.Visible;
            gameOverText.Text = "TEBRİKLER!";
            gameOverText.Foreground = new SolidColorBrush(Colors.Green);
            gameOverScoreText.Text = "Kupaya ulaştın ve oyunu kazandın!";
            
            statusText.Text = "Tebrikler! Kupaya ulaştın ve oyunu kazandın!";
        }

        private void OnRenderTimerTick(object sender, EventArgs e)
        {
            DrawMaze();
        }

        private void DrawMaze()
        {
            gameCanvas.Children.Clear();
            
            int rows = maze.GetLength(0);
            int cols = maze.GetLength(1);
            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Rectangle rect = new Rectangle();
                    rect.Width = cellSize;
                    rect.Height = cellSize;
                    rect.Fill = maze[i, j] == 1 ? new SolidColorBrush(Colors.Gray) : new SolidColorBrush(Colors.Black);
                    rect.Stroke = new SolidColorBrush(Colors.DarkGray);
                    rect.StrokeThickness = 1;
                    
                    Canvas.SetLeft(rect, j * cellSize);
                    Canvas.SetTop(rect, i * cellSize);
                    
                    gameCanvas.Children.Add(rect);
                }
            }
            
            foreach (var entrance in mapLoader.GetEntrances())
            {
                Ellipse ellipse = new Ellipse();
                ellipse.Width = cellSize;
                ellipse.Height = cellSize;
                ellipse.Fill = new SolidColorBrush(Colors.Blue);
                
                Canvas.SetLeft(ellipse, entrance.Value.GetY() * cellSize);
                Canvas.SetTop(ellipse, entrance.Value.GetX() * cellSize);
                
                gameCanvas.Children.Add(ellipse);
                
                TextBlock text = new TextBlock();
                text.Text = entrance.Key.ToString();
                text.Foreground = new SolidColorBrush(Colors.White);
                text.FontWeight = FontWeights.Bold;
                text.FontSize = cellSize / 2;
                
                Canvas.SetLeft(text, entrance.Value.GetY() * cellSize + cellSize / 3);
                Canvas.SetTop(text, entrance.Value.GetX() * cellSize + cellSize / 4);
                
                gameCanvas.Children.Add(text);
            }
            
            Image cupImage = new Image();
            cupImage.Width = cellSize;
            cupImage.Height = cellSize;
            cupImage.Source = new BitmapImage(new Uri("Images/cup.png", UriKind.Relative));
            cupImage.Stretch = Stretch.Uniform;
            
            Console.WriteLine($"DrawMaze - Kupa Çizim: Kupa konumu (X,Y)=({cupLocation.GetX()},{cupLocation.GetY()})");
            Console.WriteLine($"DrawMaze - Kupa Canvas Pozisyonu: (Left,Top)=({cupLocation.GetY() * cellSize},{cupLocation.GetX() * cellSize})");
            
            Canvas.SetLeft(cupImage, cupLocation.GetY() * cellSize);
            Canvas.SetTop(cupImage, cupLocation.GetX() * cellSize);
            
            gameCanvas.Children.Add(cupImage);
            
            foreach (Character enemy in gameEngine.GetEvilCharacters())
            {
                Image enemyImage = new Image();
                enemyImage.Width = cellSize;
                enemyImage.Height = cellSize;
                enemyImage.Stretch = Stretch.Uniform;
                
                if (enemy is DarthVader)
                {
                    enemyImage.Source = new BitmapImage(new Uri("Images/DarthVader.png", UriKind.Relative));
                }
                else if (enemy is KyloRen)
                {
                    enemyImage.Source = new BitmapImage(new Uri("Images/KyloRen.png", UriKind.Relative));
                }
                else
                {
                    enemyImage.Source = new BitmapImage(new Uri("Images/Stormtrooper.png", UriKind.Relative));
                }
                
                Canvas.SetLeft(enemyImage, enemy.GetLocation().GetY() * cellSize);
                Canvas.SetTop(enemyImage, enemy.GetLocation().GetX() * cellSize);
                
                gameCanvas.Children.Add(enemyImage);
            }
            
            Image playerImage = new Image();
            playerImage.Width = cellSize;
            playerImage.Height = cellSize;
            playerImage.Stretch = Stretch.Uniform;
            
            if (playerCharacter is LukeSkywalker)
            {
                playerImage.Source = new BitmapImage(new Uri("Images/LukeSkywalker.png", UriKind.Relative));
            }
            else
            {
                playerImage.Source = new BitmapImage(new Uri("Images/MasterYoda.png", UriKind.Relative));
            }
            
            Canvas.SetLeft(playerImage, playerCharacter.GetLocation().GetY() * cellSize);
            Canvas.SetTop(playerImage, playerCharacter.GetLocation().GetX() * cellSize);
            
            gameCanvas.Children.Add(playerImage);
        }

        private void UpdateHealthDisplay()
        {
            healthPanel.Children.Clear();
            
            double heartSize = 24;
            Thickness heartMargin = new Thickness(2, 0, 2, 0);
            
            if (playerCharacter is LukeSkywalker luke)
            {
                int health = luke.GetHealth();
                
                for (int i = 0; i < health; i++)
                {
                    TextBlock heart = new TextBlock
                    {
                        Text = "❤",
                        FontSize = heartSize,
                        Foreground = new SolidColorBrush(Colors.Red),
                        Margin = heartMargin
                    };
                    healthPanel.Children.Add(heart);
                }
                
                for (int i = health; i < 3; i++)
                {
                    TextBlock emptyHeart = new TextBlock
                    {
                        Text = "♡",
                        FontSize = heartSize,
                        Foreground = new SolidColorBrush(Colors.Gray),
                        Margin = heartMargin
                    };
                    healthPanel.Children.Add(emptyHeart);
                }
            }
            else if (playerCharacter is MasterYoda yoda)
            {
                double health = yoda.GetHealth();
                int fullHearts = (int)Math.Floor(health);
                bool hasHalfHeart = (health - fullHearts) >= 0.5;
                
                for (int i = 0; i < fullHearts; i++)
                {
                    TextBlock heart = new TextBlock
                    {
                        Text = "❤",
                        FontSize = heartSize,
                        Foreground = new SolidColorBrush(Colors.Red),
                        Margin = heartMargin
                    };
                    healthPanel.Children.Add(heart);
                }
                
                if (hasHalfHeart)
                {
                    TextBlock halfHeart = new TextBlock
                    {
                        Text = "♡",
                        FontSize = heartSize,
                        Foreground = new SolidColorBrush(Colors.OrangeRed),
                        Margin = heartMargin
                    };
                    healthPanel.Children.Add(halfHeart);
                }
                
                int totalHearts = 3;
                int remainingEmptyHearts = totalHearts - fullHearts - (hasHalfHeart ? 1 : 0);
                
                for (int i = 0; i < remainingEmptyHearts; i++)
                {
                    TextBlock emptyHeart = new TextBlock
                    {
                        Text = "♡",
                        FontSize = heartSize,
                        Foreground = new SolidColorBrush(Colors.Gray),
                        Margin = heartMargin
                    };
                    healthPanel.Children.Add(emptyHeart);
                }
            }
        }

        private void UpdateEnemyDistanceDisplay()
        {
            int distance = gameEngine.GetDistanceToNearestEnemy();
            if (distance > 0)
            {
                nearestEnemyText.Text = distance.ToString() + " adım";
            }
            else
            {
                nearestEnemyText.Text = "-";
            }
        }
    }
}
